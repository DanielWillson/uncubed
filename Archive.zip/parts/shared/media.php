<script>console.log("Alex's Stuff");</script>
<?php
$home = get_home_url();
?>
	<div id="media">
		<div class="main-container clearfix">
			<div class="edgeLogoFrontPage" alt="Uncubed Edge"></div>
			<h1>Learn skills from the startups you love.</h1>
			<br><br>
			<a href="http://edge.uncubed.com/?utm_source=uncubed&utm_medium=banner&utm_campaign=uncubed_home" class="goButton">Join Now	(it's free)</a>
		</div>
	</div>
</div>