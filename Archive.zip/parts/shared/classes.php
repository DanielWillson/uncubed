<div id="classes">
	<div class="main-container clearfix">
		<div id="classes-info">
			<h3>Learn modern skills from your favorite companies and startups.</h3>
			<h5>Subscribe for access to our short and effective online courses for only $29 / month.</h5>
			<br />
			<a href="<?php echo home_url(); ?>/classes" class="subscribe-button">Subscribe to Uncubed Classes</a>
			<br />
			<h6>Already subscribed? <a href="<?php echo home_url(); ?>/classes">View all classes here.</a></h6>
		</div>
	</div>
</div>