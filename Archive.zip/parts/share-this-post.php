<ul id="share-page">
	<a href="javascript:void(0)" class="fbA">
		<li class="fbShare">
			<img src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/social/facebook.png" />
			<h5>Share</h5>
		</li>
	</a>
	<a href="javascript:void(0)"class="twA" >
		<li class="twShare">
			<img src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/social/twitter.png" />
			<h5>Tweet</h5>
		</li>
	</a>
	<a href="javascript:void(0)" class="liA" >
		<li class="liShare">
			<img src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/social/linkedin.png" />
			<h5>LinkedIn</h5>
		</li>
	</a>
	<a href="javascript:void(0)" class="gaA">
		<li class="gShare">
			<img src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/social/googleplus.png" />
			<h5>Google+</h5>
		</li>
	</a>
</ul>
<script async src="<?php echo home_url(); ?>/wp-content/themes/uncubed/js/share-this-post.js"></script>
