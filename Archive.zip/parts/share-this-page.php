<div id="share-this-page">
	<ul>
		<a class='fb' href="javascript:void(0);"><li class='fb'><img height="20" width="20" src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/smi/fb_40.png" alt="Share on Facebook"></li></a>
		<a class='t' href="javascript:void(0);"><li class='t'><img height="20" width="20" src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/smi/twitter_40.png" alt="Tweet this"></li></a>
		<a class='in' href="javascript:void(0);"><li class='in'><img height="20" width="20" src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/smi/linkedin_40.png" alt="Share on LinkedIn"></li></a>
		<a class='gp' href="javascript:void(0);"><li class='gp'><img height="20" width="20" src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/smi/g_40.png" alt="Share with your circles"></li></a>
		<a class='pin' href="javascript:void(0);"><li class='pin'><img height="20" width="20" src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/smi/pinterest_40.png" alt="Pin to Pinterest"></li></a>
		<a class='tum' href="javascript:void(0);"><li class='tum'><img height="20" width="20" src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/smi/tumblr_40.png" alt="Post on Tumblr"></li></a>
		<a class='em' href="#"><li class='em'><img height="20" width="20" src="<?php echo home_url(); ?>/wp-content/themes/uncubed/images/smi/email_40.png" alt="Email this"></li></a>
	</ul>
	&nbsp;
</div>
<script async src="<?php echo home_url(); ?>/wp-content/themes/uncubed/js/share-this-page.js"></script>

