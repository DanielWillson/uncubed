### Uncubed WordPress Theme ###

#### Set Up ####

Pull down the repository:
- `mkdir ~/Desktop/uncubed`
- `cd ~/Desktop/uncubed`
- `git clone git@github.com:Uncubed/uncubed_WP_theme.git`
- This will create a copy of the theme on your local machine


#### To Contribute ####

Make sure you are up to date with the current master branch:
- `git pull origin master`

Make a new branch for the feature you are working on:
- `git checkout -b your-feature-branch-name`

Make changes on your new branch, test locally

When ready, push that new feature branch with your updates to github:
- `git add .`
- `git commit -m "Your commit message."`
- `git push origin your-feature-branch-name`

On github, make a new pull request for your changes.

Pushing to Staging and Production:
- Anh will review pull requests then merge into master
- Github will send you an update email notification when the changes have been merged
- Anh will pull the changes into staging
- If all looks well, Anh will push changes to production

Creating issues:
- `https://github.com/Uncubed/uncubed_WP_theme/issues`
- Issues can be created for bugs, enhancements, etc.
- Please assign yourself to an issue if you're going to work on it





