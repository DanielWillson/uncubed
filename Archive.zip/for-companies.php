<?php
/* 
Template Name: For Companies
*/
?>

<?php Starkers_Utilities::get_template_parts( array( 'parts/shared/html-header', 'parts/shared/header' ) ); ?>

  <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
    <?php the_content(); ?>

      <div class="hero-container">
        <div class="hero-text">
          <div class="companies-content">
            <h2>EMPLOYER BRANDING AND RECRUITMENT</h2>
            <h4>Uncubed helps hundreds of fast growing companies enhance their employer brand & <br> recruit great people.</h4>
            <br>
            <br>
            <br>
            <h4>Our products and services include</h4>
            <div class="companies-buttons">
              <a class="companies-btn btn" id="events">Events</a> &nbsp; 
              <a class="companies-btn btn" id="edge">Edge</a> &nbsp;
              <a class="companies-btn btn" id="delivery">Delivery</a> &nbsp;
              <a class="companies-btn btn" id="wakefield">Wakefield</a>
            </div>
            <br />
          </div>
        </div>
      </div>

      <div id="events" class="events-container" style="display:none">
        <div class="events-text">
          <h2>The Largest Employer Branding & Recruiting Event for Innovative Companies</h2>
          <h4>Uncubed organizes the "go-to" conference for hiring startups to showcase their <br> employer brand in front of thousands of curated attendees.</h4>
          <br>
          <h4>Over 500 companies have attended. Join us in one of our 4 major US Markets: <br> NYC, San Francisco, Los Angeles & Chicago.</h4>
        
          <div class="events-locations">
            <ul>
              <li>New York City</li>
              <li>Los Angeles</li>
              <li>San Francisco</li>
              <li>Chicago</li>
            </ul>
          </div>
          <div class="events-blurb bubble">
            <h4>"Not only did we hire a number of candidates directly from the conference, we noticed a 3x increase in traffic to our career page afterwards." - OnDeck</h4>
          </div>
        </div>
      </div>

      <div id="edge" class="edge-container" style="display: none">
        <div class="edge-text">
          <h2>Uncubed Edge gives candidates an inside look at how innovative <br> your company is. LEVERAGE THE POWER OF EDUCATION TO RECRUIT.</h2>
          <h4>Edge is the most realistic inside-look at what it's like to work at your company. Book a shoot on Edge and we'll help you <br> create compelling skills-based videos enhancing your employer brand through thought-leadership and attracting <br> relevant views from talented creatives.</h4>
        </div>
        <div class="edge-photo">
          <img src="http://placehold.it/900x400" alt="Edge Photo">
        </div>
        <div class="edge-companies">
          <h4>Take a peak at some of our client videos:</h4>
          <div class="row">
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
              <img alt="Gust Logo" src="images/gust-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
            </div>
    
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
              <img alt="Gust Logo" src="images/meetup-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
            </div>
    
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
              <img alt="Gust Logo" src="images/onDeck-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
            </div>
    
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
              <img alt="Gust Logo" src="images/sailthru-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
            </div>
    
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
              <img alt="Gust Logo" src="images/meetup-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
            </div>
    
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
              <img alt="Gust Logo" src="images/gust-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
            </div>
          </div>
          <div class="edge-blurb bubble">
            <h4>"Not only did we hire a number of candidates directly from the conference, we noticed a 3x increase in traffic to our career page afterwards." - OnDeck</h4>
          </div>
          <h4>For more info, visit <a href="#">http://edge.uncubed.com</a> or <a href="#">email us</a> to reserve a shoot.</h4>
        </div>
      </div>
      <br>

      <div id="delivery" class="delivery-container" style="display: none">
        <div class="delivery-text">
          <h2>Uncubed Delivery is a simple, cost effective way to receive a batch of curated candidates reletive to your needs.</h2>
          <h4>Delivery works like this.</h4>
          <div class="delivery-small-logo">
            <img alt="Delivery Logo"  style="width: 35px; height: 35px" src="images/delivery-logo-colored.png" class="small-logo">
          </div>
          <br>
          <div class="delivery-numbers mobile show">
            <ul class="row">
              <li>
                <div class="col-md-4 col-sm-4">
                  <h3 class="circle-border">1</h3>
                  <p>Fill out the application</p>
                </div>
              </li>

              <li>
                <div class="col-md-4 col-sm-4">
                  <h3 class="circle-border">2</h3>
                  <p>Approved candidates are sent to company decision makers.</p>
                </div>
              </li>
              <li>
                <div class="col-md-4 col-sm-4">
                  <h3 class="circle-border">3</h3>
                  <p>Companies reach out to you directly.</p>
                </div>
              </li>
            </ul>
            <br>
            <a class="delivery-btn btn" href="http://www.google.com">Order Delivery</a>
          </div>
        </div>
      </div>

      <div id="wakefield" class="wakefield-container" style="display: none">
        <div class="wakefield-text">
          <h2>Wakefield, Uncubed's daily email and online magazine, is a reliable and effective outlet for advertising your brand and job openings.</h2>
          <h4>Wakefield reaches over 200,000 (50K+ NYers) daily email subscribers and millions of unique visitors online. Our tech-savvy readers are educated, employed, diverse and trust Wakefield to cover cutting edge companies, amazing jobs and new tech.</h4>
          <br>
          <br>
          <h4>Who reads Wakefield?</h4>
        </div>
        <div class="wakefield-stats">
          <!-- <img class="wakefield-bg" src="https://static.pexels.com/photos/6227/hands-technology-photo-phone.jpg" alt="Wakfield Stats"> -->
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 stats-list">
              <ul>
                <li>Investors</li>
                <li>Creatives</li>
                <li>Tech Obsessed</li>
                <li>Career-Changers</li>
                <li>Innovation Leaders</li>
                <li>Modern, Creative Workforce</li>
              </ul>
            </div>
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 stats-list">
            <img src="images/people-stats.png" alt="User Stats" style="width: 100px; height: 100px">
            <h4>50% &nbsp; 50%</h4>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 stats-list">
            <h2>25-40 <br> age range</h2>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 stats-list">
            <img src="images/college-stats.png" alt="User Stats" style="width: 100px; height: 100px">
            <h4>college educated</h4>
          </div>
        </div>
      </div>
      <div class="wakefield-contact">
        <h4>Download our <a href="#">media kit</a> for details and pricing or <a href="#">email us</a> for availability</h4>
        <br>
        <h4>Uncubed has helped hundreds of fast growing companies</h4>
      </div>

      <div class="company-container">
        <div class="row">
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/gust-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/meetup-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/onDeck-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/sailthru-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/meetup-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/gust-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/sailthru-logo.png" style="size:height: 100px; width:100px" class="desaturate" />
          </div>
          <br>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/onDeck-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/meetup-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/gust-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/onDeck-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
  
          <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2 company-wrapper">
            <img alt="Gust Logo" src="images/onDeck-logo.png" style="size:height: 150px; width:100px" class="desaturate" />
          </div>
        </div>
      </div>
    </div>
  <?php endwhile; ?>
<?php Starkers_Utilities::get_template_parts( array( 'parts/shared/footer','parts/shared/html-footer' ) ); ?>
